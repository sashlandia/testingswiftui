//
//  PracticeAppApp.swift
//  PracticeApp
//
//  Created by Sasha on 13.05.2024.
//

import SwiftUI

@main
struct PracticeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
