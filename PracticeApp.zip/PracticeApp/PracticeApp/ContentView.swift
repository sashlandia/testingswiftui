//
//  ContentView.swift
//  PracticeApp
//
//  Created by Sasha on 13.05.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        ZStack {
            Image("sunnyfilka")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .clipShape(Circle())
            
            Text("It's me - Filka")
                .font(.largeTitle)
                .foregroundColor(.white)
                .background(.red)
                .padding(1)
                .background(.white)
                .padding(2)
        }
        
        
    }
    
    
    //        ZStack(alignment: .bottomLeading, content: {
    //            Text("It is me - Filka")
    //                .font(.largeTitle)
    //                .background(Color.pink)
    //                .foregroundColor(Color.white)
    //
    //        })
    //Image("sunnyfilka")
}

#Preview {
    ContentView()
}
